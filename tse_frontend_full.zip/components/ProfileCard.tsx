'use client'

import { useState, useEffect } from 'react'

export default function ProfileCard() {
  const [profile, setProfile] = useState(null)

  useEffect(() => {
    fetch('/api/user/me').then(res => res.json()).then(setProfile)
  }, [])

  if (!profile) return <p>Loading...</p>

  return (
    <div className="p-6 bg-white rounded shadow-md max-w-xl mx-auto mt-8">
      <h2 className="text-xl font-bold mb-2">{profile.name}</h2>
      <p className="text-gray-700 mb-2">Email: {profile.email}</p>
      <p className="text-gray-700">Role: {profile.role}</p>
    </div>
  )
}
