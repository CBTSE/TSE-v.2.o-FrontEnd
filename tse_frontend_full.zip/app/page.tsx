export default function HomePage() {
  return <div className="p-10 text-xl font-bold">Welcome to The Sports Exchange!</div>
}
